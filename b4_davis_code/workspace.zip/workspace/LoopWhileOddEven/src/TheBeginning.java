

/*
 * Graded
 * JOP;s with Jar'd up
 * you may use syso but then get rid of them or they wont jar
 * ask user for a number (int)
 * test that number for odd or even
 * JOP the result "your number us odd/ even
 * ask user "do youwant to go again Yes or now
 * if no, "thanks you"
 * If yes, go again ask for a new number
 * 
 */
public class TheBeginning {

	public static void main(String[] args) {
		
	}

}
