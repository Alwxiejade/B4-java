
//Graded
//Use syso's
//Goal make a times table
//ask the user for a number, then make a times table
//ex 6 show (formatted)
// 1 x 6 = 6
//ect
//ends when number multiplys itself
// end 9 x 9 = 81




public class Loops {

	public static void main(String[] args) {
		
		int multiplication = 0;
		
		for (int i = 1; i <= ; i++){
			
			multiplication = multiplication + i;
			System.out.println("i, addition: " + i + ", " + addition);
		};

	}

}
