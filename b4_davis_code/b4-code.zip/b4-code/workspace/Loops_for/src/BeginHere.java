
public class BeginHere {

	public static void main(String[] args) {
		
		/*
		
		
		for (int i = 0; i <=10; i++){
			
			
			System.out.println("Vaule of i is: " + i);
		
		}
		*/
		/*
		int start, end=15;
		
		for (start = 30; start >= end; start-- ){
			
			System.out.println("Countdown: " + start);
		}
		*/
		
		int addition = 0;
		
		for (int i = 1; i <= 100; i++){
			
			addition = addition + i;
			System.out.println("i, addition: " + i + ", " + addition);
		};
		
		
		// on your own (practice)
		// add all numbers from 1 to 100 using a loop
		// 1+2+3 + 100
		//syso the sum the answer
		
		
		
	}

}
