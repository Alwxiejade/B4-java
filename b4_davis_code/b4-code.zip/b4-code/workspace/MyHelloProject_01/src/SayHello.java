
public class SayHello {

	public static void main(String[] args) {
		
		System.out.println(" NO, I am creating a Java program! "); 
		System.out.println(" Hello my name is Alex "); 
		System.out.println(" I am a junior! "); 
		System.out.println(" I have no idea what I want to do with my life. "); 

	}

}
