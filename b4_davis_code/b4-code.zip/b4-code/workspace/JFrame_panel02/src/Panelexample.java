import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Panelexample {
	
	
	/*
	 * GRADED!
	 * Have 4 JPanels, each with a different color (we did red, blue)
	 * JFrame must be 800 x 600 ( we did 600 x 400)
	 * All 
	 */
	
	
	public JPanel createContentPane(){
		
		//WE create a bottom JPane; to place everything on.
		JPanel totalGUI = new JPanel();
		
		//We set the Layout Manager to null so we can manually place
		//the panels
		totalGUI.setLayout(null);
		
		//Now we create a new panel, size it, shape it, color it red.
		//then add it to the bottom JPanel.
		JPanel redPanel = new JPanel();
		redPanel.setBackground(Color.RED);
		redPanel.setLocation(0, 0);
		redPanel.setSize(400,300);
		totalGUI.add(redPanel);
		
		JPanel bluePanel = new JPanel();
		bluePanel.setBackground(Color.BLUE);
		bluePanel.setLocation(400 , 0 );
		bluePanel.setSize(400,300);
		totalGUI.add(bluePanel);

		JPanel orangePanel = new JPanel();
		orangePanel.setBackground(Color.ORANGE);
		orangePanel.setLocation(0 ,300 );
		orangePanel.setSize(400,300);
		totalGUI.add(orangePanel);
		
		JPanel magentaPanel = new JPanel();
		magentaPanel.setBackground(Color.MAGENTA);
		magentaPanel.setLocation(400 , 300 );
		magentaPanel.setSize(400,300);
		totalGUI.add(magentaPanel);
		
		//Finally we return the JPanel
		totalGUI.setOpaque(true);
		return totalGUI;

		
		
	
	}


	public static void main(String[] args) {
		
		createAndShowGUI();

	}

	private static void createAndShowGUI() {
		
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame frame = new JFrame("There are 3 JPanels in here!");
		
		//Create and set up the content pane.
		Panelexample demo = new Panelexample();
		frame.setContentPane(demo.createContentPane());
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800, 600);
		frame.setVisible(true);
		
	}

}
